function myFunction() {
    console.log("hoi");
    const body = document.querySelector("body").classList.toggle("maks")
}